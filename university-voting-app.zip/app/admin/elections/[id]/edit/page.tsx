import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import ElectionForm from "@/components/election-form"

export default async function EditElectionPage({ params }: { params: { id: string } }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", session.user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch election details
  const { data: election, error } = await supabase.from("elections").select("*").eq("id", params.id).single()

  if (error || !election) {
    redirect("/admin")
  }

  return <ElectionForm election={election} />
}
