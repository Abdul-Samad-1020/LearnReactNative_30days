import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import CandidateManagement from "@/components/candidate-management"

export default async function CandidatesPage({ params }: { params: { id: string } }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", session.user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch election details
  const { data: election, error: electionError } = await supabase
    .from("elections")
    .select("*")
    .eq("id", params.id)
    .single()

  if (electionError || !election) {
    redirect("/admin")
  }

  // Fetch candidates for this election
  const { data: candidates } = await supabase.from("candidates").select("*").eq("election_id", params.id).order("name")

  return <CandidateManagement election={election} candidates={candidates || []} />
}
