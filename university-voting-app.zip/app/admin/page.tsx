import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import AdminClient from "@/components/admin-client"

export default async function AdminPage() {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", session.user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch all elections
  const { data: elections } = await supabase.from("elections").select("*").order("created_at", { ascending: false })

  return <AdminClient elections={elections || []} />
}
