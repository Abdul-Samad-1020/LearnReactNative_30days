import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import DashboardClient from "@/components/dashboard-client"

export default async function Dashboard() {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Fetch active elections
  const { data: elections } = await supabase.from("elections").select("*").order("created_at", { ascending: false })

  // Fetch user's votes to determine which elections they've already voted in
  const { data: userVotes } = await supabase.from("votes").select("election_id").eq("user_id", session.user.id)

  const votedElectionIds = userVotes?.map((vote) => vote.election_id) || []

  // Get user profile data
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  const isAdmin = profile?.role === "admin"

  return (
    <DashboardClient
      user={session.user}
      elections={elections || []}
      votedElectionIds={votedElectionIds}
      isAdmin={isAdmin}
    />
  )
}
