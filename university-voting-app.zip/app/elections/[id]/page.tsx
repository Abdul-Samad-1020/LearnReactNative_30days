import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import VotingClient from "@/components/voting-client"

export default async function ElectionPage({ params }: { params: { id: string } }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Fetch election details
  const { data: election, error: electionError } = await supabase
    .from("elections")
    .select("*")
    .eq("id", params.id)
    .single()

  if (electionError || !election) {
    redirect("/dashboard")
  }

  // Check if election is active
  if (election.status !== "active") {
    redirect("/dashboard")
  }

  // Check if user has already voted
  const { data: existingVote, error: voteError } = await supabase
    .from("votes")
    .select("*")
    .eq("user_id", session.user.id)
    .eq("election_id", params.id)
    .maybeSingle()

  if (existingVote) {
    redirect(`/elections/${params.id}/results`)
  }

  // Fetch candidates for this election
  const { data: candidates } = await supabase.from("candidates").select("*").eq("election_id", params.id).order("name")

  return <VotingClient election={election} candidates={candidates || []} userId={session.user.id} />
}
