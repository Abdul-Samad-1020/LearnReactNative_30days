import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import ResultsClient from "@/components/results-client"

export default async function ResultsPage({ params }: { params: { id: string } }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Fetch election details
  const { data: election, error: electionError } = await supabase
    .from("elections")
    .select("*")
    .eq("id", params.id)
    .single()

  if (electionError || !election) {
    redirect("/dashboard")
  }

  // Fetch candidates with vote counts
  const { data: candidates } = await supabase
    .from("candidates")
    .select("*")
    .eq("election_id", params.id)
    .order("votes", { ascending: false })

  // Calculate total votes
  const totalVotes = candidates?.reduce((sum, candidate) => sum + (candidate.votes || 0), 0) || 0

  // Check if user has voted in this election
  const { data: userVote } = await supabase
    .from("votes")
    .select("candidate_id")
    .eq("user_id", session.user.id)
    .eq("election_id", params.id)
    .maybeSingle()

  const userVotedFor = userVote?.candidate_id || null

  return (
    <ResultsClient
      election={election}
      candidates={candidates || []}
      totalVotes={totalVotes}
      userVotedFor={userVotedFor}
    />
  )
}
