"use client"

import { useState } from "react"
import Link from "next/link"
import type { User } from "@supabase/supabase-js"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, CheckCircle, Clock } from "lucide-react"

interface Election {
  id: string
  title: string
  description: string
  start_date: string
  end_date: string
  status: "upcoming" | "active" | "completed"
}

interface DashboardClientProps {
  user: User
  elections: Election[]
  votedElectionIds: string[]
  isAdmin: boolean
}

export default function DashboardClient({ user, elections, votedElectionIds, isAdmin }: DashboardClientProps) {
  const [activeTab, setActiveTab] = useState("active")

  const filteredElections = elections.filter((election) => {
    if (activeTab === "active") return election.status === "active"
    if (activeTab === "upcoming") return election.status === "upcoming"
    if (activeTab === "completed") return election.status === "completed"
    return true
  })

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">University Elections Dashboard</h1>
        {isAdmin && (
          <Link href="/admin">
            <Button>Admin Panel</Button>
          </Link>
        )}
      </div>

      <Tabs defaultValue="active" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">Active Elections</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming Elections</TabsTrigger>
          <TabsTrigger value="completed">Completed Elections</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {filteredElections.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No {activeTab} elections found.</p>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredElections.map((election) => (
                <Card key={election.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle>{election.title}</CardTitle>
                      <Badge
                        variant={
                          election.status === "active"
                            ? "default"
                            : election.status === "upcoming"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {election.status.charAt(0).toUpperCase() + election.status.slice(1)}
                      </Badge>
                    </div>
                    <CardDescription>{election.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center text-sm">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        <span>
                          {formatDate(election.start_date)} - {formatDate(election.end_date)}
                        </span>
                      </div>
                      {votedElectionIds.includes(election.id) && (
                        <div className="flex items-center text-sm text-green-600">
                          <CheckCircle className="mr-2 h-4 w-4" />
                          <span>You have voted in this election</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    {election.status === "active" ? (
                      votedElectionIds.includes(election.id) ? (
                        <Link href={`/elections/${election.id}/results`} className="w-full">
                          <Button variant="outline" className="w-full">
                            View Results
                          </Button>
                        </Link>
                      ) : (
                        <Link href={`/elections/${election.id}`} className="w-full">
                          <Button className="w-full">Vote Now</Button>
                        </Link>
                      )
                    ) : election.status === "completed" ? (
                      <Link href={`/elections/${election.id}/results`} className="w-full">
                        <Button variant="outline" className="w-full">
                          View Results
                        </Button>
                      </Link>
                    ) : (
                      <Button disabled className="w-full">
                        <Clock className="mr-2 h-4 w-4" />
                        Coming Soon
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
