"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, ArrowLeft, CalendarIcon } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createClient } from "@/utils/supabase/client"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ElectionFormProps {
  election?: {
    id: string
    title: string
    description: string
    start_date: string
    end_date: string
    status: "upcoming" | "active" | "completed"
  }
}

export default function ElectionForm({ election }: ElectionFormProps) {
  const isEditing = !!election
  const [title, setTitle] = useState(election?.title || "")
  const [description, setDescription] = useState(election?.description || "")
  const [startDate, setStartDate] = useState(
    election?.start_date ? new Date(election.start_date).toISOString().split("T")[0] : "",
  )
  const [endDate, setEndDate] = useState(
    election?.end_date ? new Date(election.end_date).toISOString().split("T")[0] : "",
  )
  const [status, setStatus] = useState(election?.status || "upcoming")
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      if (!title || !description || !startDate || !endDate) {
        throw new Error("Please fill in all required fields")
      }

      const start = new Date(startDate)
      const end = new Date(endDate)

      if (end <= start) {
        throw new Error("End date must be after start date")
      }

      const electionData = {
        title,
        description,
        start_date: start.toISOString(),
        end_date: end.toISOString(),
        status,
      }

      if (isEditing) {
        // Update existing election
        const { error: updateError } = await supabase.from("elections").update(electionData).eq("id", election.id)

        if (updateError) throw updateError
      } else {
        // Create new election
        const { error: insertError } = await supabase.from("elections").insert(electionData)

        if (insertError) throw insertError
      }

      router.push("/admin")
      router.refresh()
    } catch (error: any) {
      setError(error.message || "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-6 max-w-2xl">
      <Link href="/admin" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Admin Panel
      </Link>

      <Card>
        <CardHeader>
          <CardTitle>{isEditing ? "Edit Election" : "Create New Election"}</CardTitle>
          <CardDescription>
            {isEditing ? "Update the details of this election" : "Fill in the details to create a new election"}
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="title">Election Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Student Council Election 2023"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Provide details about this election..."
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date</Label>
                <div className="relative">
                  <CalendarIcon className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    id="startDate"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate">End Date</Label>
                <div className="relative">
                  <CalendarIcon className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    id="endDate"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger id="status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : isEditing ? "Update Election" : "Create Election"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
