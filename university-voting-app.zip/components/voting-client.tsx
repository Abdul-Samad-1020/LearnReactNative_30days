"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { AlertCircle, ArrowLeft, CalendarIcon, CheckCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createClient } from "@/utils/supabase/client"
import Link from "next/link"

interface Candidate {
  id: string
  name: string
  bio: string
  photo_url?: string
  election_id: string
}

interface Election {
  id: string
  title: string
  description: string
  start_date: string
  end_date: string
}

interface VotingClientProps {
  election: Election
  candidates: Candidate[]
  userId: string
}

export default function VotingClient({ election, candidates, userId }: VotingClientProps) {
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [voteSubmitted, setVoteSubmitted] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleVote = async () => {
    if (!selectedCandidate) {
      setError("Please select a candidate to vote")
      return
    }

    setLoading(true)
    setError(null)

    try {
      // Insert vote record
      const { error: voteError } = await supabase.from("votes").insert({
        user_id: userId,
        election_id: election.id,
        candidate_id: selectedCandidate,
      })

      if (voteError) {
        throw voteError
      }

      // Update candidate vote count
      const { error: updateError } = await supabase.rpc("increment_candidate_votes", {
        candidate_id_param: selectedCandidate,
      })

      if (updateError) {
        throw updateError
      }

      setVoteSubmitted(true)

      // Redirect to results after a short delay
      setTimeout(() => {
        router.push(`/elections/${election.id}/results`)
        router.refresh()
      }, 2000)
    } catch (error: any) {
      setError(error.message || "An error occurred while submitting your vote")
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  if (voteSubmitted) {
    return (
      <div className="container mx-auto py-12 max-w-md">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Vote Submitted!</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-6">
            <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
            <p className="text-center">Thank you for participating in the election. Your vote has been recorded.</p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-gray-500">Redirecting to results page...</p>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 max-w-2xl">
      <Link href="/dashboard" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Link>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{election.title}</CardTitle>
          <CardDescription>{election.description}</CardDescription>
          <div className="flex items-center text-sm mt-2">
            <CalendarIcon className="mr-2 h-4 w-4" />
            <span>
              {formatDate(election.start_date)} - {formatDate(election.end_date)}
            </span>
          </div>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Select a candidate:</h3>

            <RadioGroup value={selectedCandidate || ""} onValueChange={setSelectedCandidate}>
              <div className="space-y-4">
                {candidates.map((candidate) => (
                  <Card
                    key={candidate.id}
                    className={`cursor-pointer border-2 transition-all ${
                      selectedCandidate === candidate.id ? "border-primary" : "border-transparent"
                    }`}
                    onClick={() => setSelectedCandidate(candidate.id)}
                  >
                    <CardContent className="p-4 flex items-start gap-4">
                      <RadioGroupItem value={candidate.id} id={candidate.id} className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor={candidate.id} className="text-base font-medium cursor-pointer">
                          {candidate.name}
                        </Label>
                        <p className="text-sm text-gray-500 mt-1">{candidate.bio}</p>
                      </div>
                      {candidate.photo_url && (
                        <div className="h-16 w-16 rounded-full overflow-hidden bg-gray-100 flex-shrink-0">
                          <img
                            src={candidate.photo_url || "/placeholder.svg"}
                            alt={candidate.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </RadioGroup>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleVote} disabled={!selectedCandidate || loading} className="w-full">
            {loading ? "Submitting Vote..." : "Submit Vote"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
