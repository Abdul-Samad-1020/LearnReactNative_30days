"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, CalendarIcon, Edit, Plus } from "lucide-react"
import { useRouter } from "next/navigation"

interface Election {
  id: string
  title: string
  description: string
  start_date: string
  end_date: string
  status: "upcoming" | "active" | "completed"
}

interface AdminClientProps {
  elections: Election[]
}

export default function AdminClient({ elections }: AdminClientProps) {
  const [activeTab, setActiveTab] = useState("all")
  const router = useRouter()

  const filteredElections = elections.filter((election) => {
    if (activeTab === "active") return election.status === "active"
    if (activeTab === "upcoming") return election.status === "upcoming"
    if (activeTab === "completed") return election.status === "completed"
    return true
  })

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="flex items-center text-sm hover:underline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold">Admin Panel</h1>
        </div>
        <Link href="/admin/elections/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Create Election
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="all" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Elections</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {filteredElections.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No elections found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredElections.map((election) => (
                <Card key={election.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle>{election.title}</CardTitle>
                      <Badge
                        variant={
                          election.status === "active"
                            ? "default"
                            : election.status === "upcoming"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {election.status.charAt(0).toUpperCase() + election.status.slice(1)}
                      </Badge>
                    </div>
                    <CardDescription>{election.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center text-sm">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        <span>
                          {formatDate(election.start_date)} - {formatDate(election.end_date)}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Link href={`/admin/elections/${election.id}/candidates`}>
                          <Button variant="outline" size="sm">
                            Manage Candidates
                          </Button>
                        </Link>
                        <Link href={`/admin/elections/${election.id}/edit`}>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Link href={`/elections/${election.id}/results`}>
                          <Button variant="outline" size="sm">
                            View Results
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
