"use client"

import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, CalendarIcon, CheckCircle, Trophy } from "lucide-react"

interface Candidate {
  id: string
  name: string
  bio: string
  photo_url?: string
  votes: number
}

interface Election {
  id: string
  title: string
  description: string
  start_date: string
  end_date: string
  status: "upcoming" | "active" | "completed"
}

interface ResultsClientProps {
  election: Election
  candidates: Candidate[]
  totalVotes: number
  userVotedFor: string | null
}

export default function ResultsClient({ election, candidates, totalVotes, userVotedFor }: ResultsClientProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const calculatePercentage = (votes: number) => {
    if (totalVotes === 0) return 0
    return Math.round((votes / totalVotes) * 100)
  }

  return (
    <div className="container mx-auto py-6 max-w-2xl">
      <Link href="/dashboard" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Link>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-2xl">{election.title} Results</CardTitle>
            <Badge
              variant={
                election.status === "active" ? "default" : election.status === "upcoming" ? "secondary" : "outline"
              }
            >
              {election.status.charAt(0).toUpperCase() + election.status.slice(1)}
            </Badge>
          </div>
          <CardDescription>{election.description}</CardDescription>
          <div className="flex items-center text-sm mt-2">
            <CalendarIcon className="mr-2 h-4 w-4" />
            <span>
              {formatDate(election.start_date)} - {formatDate(election.end_date)}
            </span>
          </div>
          <div className="text-sm mt-2">
            Total votes: <span className="font-medium">{totalVotes}</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {candidates.map((candidate, index) => (
              <div key={candidate.id} className="space-y-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    {index === 0 && election.status === "completed" && <Trophy className="h-5 w-5 text-yellow-500" />}
                    <div>
                      <h3 className="font-medium">
                        {candidate.name}
                        {userVotedFor === candidate.id && (
                          <span className="ml-2 inline-flex items-center text-green-600 text-sm">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Your vote
                          </span>
                        )}
                      </h3>
                      <p className="text-sm text-gray-500">{candidate.votes} votes</p>
                    </div>
                  </div>
                  <span className="font-medium">{calculatePercentage(candidate.votes)}%</span>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                  <div
                    className="bg-primary h-2.5 rounded-full"
                    style={{ width: `${calculatePercentage(candidate.votes)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
