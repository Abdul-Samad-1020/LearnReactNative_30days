"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, ArrowLeft, Plus, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createClient } from "@/utils/supabase/client"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface Candidate {
  id: string
  name: string
  bio: string
  photo_url?: string
  election_id: string
}

interface Election {
  id: string
  title: string
  description: string
}

interface CandidateManagementProps {
  election: Election
  candidates: Candidate[]
}

export default function CandidateManagement({ election, candidates: initialCandidates }: CandidateManagementProps) {
  const [candidates, setCandidates] = useState(initialCandidates)
  const [name, setName] = useState("")
  const [bio, setBio] = useState("")
  const [photoUrl, setPhotoUrl] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleAddCandidate = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      if (!name || !bio) {
        throw new Error("Name and bio are required")
      }

      const candidateData = {
        name,
        bio,
        photo_url: photoUrl || null,
        election_id: election.id,
        votes: 0,
      }

      const { data, error: insertError } = await supabase.from("candidates").insert(candidateData).select().single()

      if (insertError) throw insertError

      setCandidates([...candidates, data])
      setName("")
      setBio("")
      setPhotoUrl("")
      setIsDialogOpen(false)
      router.refresh()
    } catch (error: any) {
      setError(error.message || "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteCandidate = async (candidateId: string) => {
    if (!confirm("Are you sure you want to delete this candidate?")) {
      return
    }

    try {
      const { error: deleteError } = await supabase.from("candidates").delete().eq("id", candidateId)

      if (deleteError) throw deleteError

      setCandidates(candidates.filter((c) => c.id !== candidateId))
      router.refresh()
    } catch (error: any) {
      alert(`Error deleting candidate: ${error.message}`)
    }
  }

  return (
    <div className="container mx-auto py-6 max-w-3xl">
      <Link href="/admin" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Admin Panel
      </Link>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Manage Candidates</CardTitle>
              <CardDescription>{election.title} - Add or remove candidates for this election</CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Candidate
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Candidate</DialogTitle>
                  <DialogDescription>Enter the details for the new candidate</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddCandidate}>
                  {error && (
                    <Alert variant="destructive" className="mb-4">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Candidate Name</Label>
                      <Input
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter candidate name"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={bio}
                        onChange={(e) => setBio(e.target.value)}
                        placeholder="Brief description of the candidate"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="photoUrl">Photo URL (Optional)</Label>
                      <Input
                        id="photoUrl"
                        value={photoUrl}
                        onChange={(e) => setPhotoUrl(e.target.value)}
                        placeholder="https://example.com/photo.jpg"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={loading}>
                      {loading ? "Adding..." : "Add Candidate"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {candidates.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No candidates added yet.</p>
              <p className="text-gray-500 text-sm mt-2">
                Click the "Add Candidate" button to add candidates to this election.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {candidates.map((candidate) => (
                <Card key={candidate.id}>
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      {candidate.photo_url && (
                        <div className="h-12 w-12 rounded-full overflow-hidden bg-gray-100">
                          <img
                            src={candidate.photo_url || "/placeholder.svg"}
                            alt={candidate.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                      )}
                      <div>
                        <h3 className="font-medium">{candidate.name}</h3>
                        <p className="text-sm text-gray-500 line-clamp-1">{candidate.bio}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteCandidate(candidate.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
